package br.ufc.quixada.app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

public class BlankFragment2 extends Fragment {
    String [] itens = {"Item 1", "Item 2", "Item 3"};
    AutoCompleteTextView autoCompleteTextView;
    ArrayAdapter<String> adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_blank2, container, false);
        createRadioButton(v);
        createLongPress(v);
        createDropdown(v);

        return v;
    }

    //Radio Button
    public void createRadioButton(View v){
        RadioGroup radioGroup = v.findViewById(R.id.radioGroup);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch(checkedId) {
                    case R.id.radioButton7:
                        break;
                    case R.id.radioButton6:
                        break;
                }
            }
        });
    }
    //Radio Button

    //Long press
    public void createLongPress(View v){
        TextView txtView = v.findViewById(R.id.txtViewLongPress);
        txtView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Toast.makeText(getActivity(), "Pressionado",Toast.LENGTH_LONG).show();
                return true;
            }
        });
        txtView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "Pressione mais!", Toast.LENGTH_SHORT).show();
            }
        });

    }
    //Long press

    //DropDown Menu
    public void createDropdown(View v){
        autoCompleteTextView = v.findViewById(R.id.autoCompletetxt);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(v.getContext(), R.layout.list_item,itens);
        autoCompleteTextView.setAdapter(adapter);

        autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String itens = adapterView.getItemAtPosition(i).toString();
                Toast.makeText(adapterView.getContext(),"Item: " + itens, Toast.LENGTH_SHORT).show();

            }
        });
    }
    //DropDown Menu
}